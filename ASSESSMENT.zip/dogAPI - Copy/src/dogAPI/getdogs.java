package dogAPI;

public class getdogs {

	public static void main(String[] args) {
		
		
		dogs.randomDog();
		dogs.breedDog();
		dogs.breedDogsImages();
		

	}

}
